/*
 * $safeprojectname$.cpp
 *
 * Created: 5/6/2016 8:41:24 AM
 * Author : lenovo
 */ 

#include <avr/io.h>
#include "SimulateDebug.h"

/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

